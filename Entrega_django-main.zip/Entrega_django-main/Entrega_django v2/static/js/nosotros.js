function postulacion(){
console.log("Enviar se Presiono")
var Nombre = document.getElementById("nombre").value;
var Nombre = document.getElementById("edad").value;
var Nombre = document.getElementById("telefono").value;
var Nombre = document.getElementById("email").value;
// var Nombre = document.getElementById("ingles").value;

}