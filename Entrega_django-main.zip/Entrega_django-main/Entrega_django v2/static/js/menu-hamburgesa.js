var menuList = document.getElementById("menuList");

function toggleMenu() {
  menuList.classList.toggle("responsive");
}
